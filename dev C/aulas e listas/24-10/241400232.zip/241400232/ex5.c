#include <stdio.h>
#include <string.h>

int main () {
	
	char str1[]="Ceticismo da fe";
	char str2[10];
	
	printf("resultado: %s",strncpy(str2,str1,5));
	
	
	
	
	
	return 0;
}
