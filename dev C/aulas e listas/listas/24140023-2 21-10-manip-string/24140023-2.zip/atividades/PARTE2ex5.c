
#include <stdio.h>
#include <string.h>

void ContadorPal(char* a);
char pal[25][50];
int c=0;


int main(){
	char frase[50];
	printf("Por favor, digite uma frase: ");
	gets(frase);
	ContadorPal(frase);
	printf("Quantidade de palavras presente na frase: %d",c);
	return 0;
}
//n sei qual � melhor, montar a funcao em baixo do main ou em cima, ou se da na mesma
void ContadorPal(char* a){
	
	char e[50];
	int x=0;
	int i=0;
	
	while (x <= strlen(a)){
		if(a[x] == ' ' || a[x] == '\0'){
			e[i] = '\0';
			strcpy(pal[i],e);
			c++;
			i=0;
		} else {
			e[i] = a[x];
			i++;
		}
		x++;
	}
}
