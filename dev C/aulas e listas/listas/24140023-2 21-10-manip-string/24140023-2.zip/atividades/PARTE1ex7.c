
#include <stdio.h>
#include <string.h>

int main(){
	char string[50];
	int x;
	printf("Por favor, digite uma string qualquer: ");
	gets(string);
	for(x = 0; x< strlen(string); x++){
		switch(string[x]) { //poderia ter feito if e else, mas com switch ficou melhor
            case 'a':
                string[x] = '!';
                break;
            case 'e':
                string[x] = '@';
                break;
            case 'i':
                string[x] = '#';
                break;
            case 'o':
                string[x] = '$';
                break;
            case 'u':
                string[x] = '%';
                break;
        }
        
	}
	
	printf("%s",string);
	

	return 0;
}  	
