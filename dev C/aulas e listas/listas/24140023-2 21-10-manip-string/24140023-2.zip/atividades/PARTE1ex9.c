
#include <stdio.h>
#include <string.h>

void maiusc(char* a);
void minusc(char* b);

int main(){
	char string[50];
	int op;
	printf("Por favor, digite uma string: ");
	gets(string);
	do { 
		printf("Atente-se as opcoes de escolhas:\n");
		printf("01- Transformar a string inteira em maiuscula\n");
		printf("02- Transformar a string inteira em minuscula\n");
		scanf("%d",&op);
		if (op != 1 && op != 2) {
			printf("Opcao invalida.Tente novamente!");
		}
	} while (op != 1 && op != 2);
	
	if(op == 1) {
		maiusc(string);
	} else if(op == 2) {
		minusc(string);
	}
	
	
	return 0;
}


void maiusc(char* a){
	int x;
	
	for (x = 0; x < strlen(a); x++) {
        if (a[x] >= 'a' && a[x] <= 'z') {
            a[x] = a[x] - 32;
        }
    }
    printf("%s (maiusculo)",a);
}



void minusc(char* b){
	
	int x;
	for (x = 0; x < strlen(b); x++) {
        if (b[x] >= 'A' && b[x] <= 'Z') {
            b[x] = b[x] + 32;
        }
    }
    printf("%s (minusculo)",b);
}
