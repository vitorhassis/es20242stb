#include <stdio.h>
#include <string.h>


int main () {
	char string [30];
	int x;
	
	
	printf("Digite uma frase/string: ");
	gets(string);
	
	for (int x=0;x<strlen(string);x++) {
		switch (string[x]) {
			case 'a':
				string[x] = ' ';
				break;
			case 'e':
				string[x] = ' ';
				break;
			case 'i':				//talvez tenha como fazer isso mais simplificado
				string[x] = ' ';
				break;
			case 'o':
				string[x] = ' ';
				break;
			case 'u':
				string[x] = ' ';
				break;
		}	
		
	}
	
	printf("temos como resultado = %s",string);
		
	return 0;
}
