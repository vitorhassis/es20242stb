
#include <stdio.h>
#include <string.h>

char string[50];
void RemovDupl(char* a){
	int x;
	int i;
	int cont=0;
	for(x = 0; x<strlen(a); x++){ 
		for(i = 0; i < strlen(a); i++){ 
			if(a[x] == a[i] && x != i){
				a[i] = ' ';
				cont++; //+1
			}
		}
		
		if(cont>0) a[x] = ' ';
		cont= 0;
	}
}


int main(){
	printf("por favor, digite uma string qualquer: ");
	gets(string);
	RemovDupl(string);
	printf("Removendo as string duplicadas, ficamos com o resultado final: %s",string);
	return 0;
}
