
#include <stdio.h>
#include <string.h>

void pal(char* a);
char string[25][50];
int i=0;

int main(){
	char frase[50];
	int x;
	printf("Por favor, digite uma frase: ");
	gets(frase);
	pal(frase);
	
	for(x=0; x<i; x++){
		printf("%d string: %s\n",x+1, string[x]);
	}
	return 0;
}

void pal(char* a){
	char st[50];
	int x=0;
	int c=0;
	while (x <= strlen(a)){
		if(a[x] == ' ' || a[x] == '\0'){
			st[c] = '\0';
			strcpy(string[i],st);
			i++;
			c=0;
		} else {
			st[c] = a[x];
			c++;
		}
		
		x++;
	}
}
