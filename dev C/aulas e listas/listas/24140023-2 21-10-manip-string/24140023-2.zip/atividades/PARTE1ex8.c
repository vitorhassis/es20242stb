
#include <stdio.h>
#include <string.h>

int buscar(char *a ,char *b){
	char palavra[50];
	int x=0;
	int i=0;
	int qnt=0;
while (x <= strlen(a)) {
        if (a[x] == ' ' || a[x] == '\0') {
            palavra[i] = '\0';
            if (strcmp(palavra, b) == 0) {
            	qnt++;
            }
            i = 0;
        } else {
            palavra[i] = a[x];
            i++;
        }
        x++;
    }
    if (qnt > 0) {
   		 return qnt;		
    }else return 0;
}



int main(){
	char string[50];
	char subString[50];
	printf("Por favor, digite uma frase: ");
	gets(string);
	printf("Digite uma string. Sera informado se ela eh uma substring da principal, ou nao: ");
	scanf("%s",subString);
	if(buscar(string,subString) == 1) {
		printf("sim, eh uma subString da frase = %s",string);
	} else if (buscar(string,subString) >= 0) {
		printf("Nao foi encontrado uma subString da frase principal.",buscar(string,subString));
	}
		
		
		
		
		
	return 0;
}
