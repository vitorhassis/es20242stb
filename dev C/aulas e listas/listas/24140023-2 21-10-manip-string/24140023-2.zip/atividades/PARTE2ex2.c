
#include <stdio.h>
#include <string.h>

int main(){
	char string1[50];
	char string2[50];
	
	printf("Digite uma string qualquer: ");
	gets(string1);
	printf("Digite outra string: ");
	gets(string2);
	
	if(strcmp(string1,string2) == 0){
		printf("Palavras/strings iguais!");
	}else {
		printf("Palavras/strings nao sao iguais!");
	}
	

	return 0;
}
