#include <stdio.h>
#include <string.h>
#include <locale.h>


int main(){
	
char string1[50];
char string2[50];
char teste[50];
int i;
int x;
x=0;

	printf("Por favor, infome a primeira string: ");
	gets(string1);
	printf("Informe a segunda string: ");
	gets(string2);

for(i= strlen(string1)-1; i >= 0; i--){
	teste[x] = string1[i];
	x++;
}

if(strcmp(teste, string2) == 0){
	printf("AS STRINGS INFORMADAS SAO ANAGRAMAS");
}else{
	printf("AS STRINGS INFORMADAS NAO SAO ANAGRAMAS");
}

return 0 ;
}
