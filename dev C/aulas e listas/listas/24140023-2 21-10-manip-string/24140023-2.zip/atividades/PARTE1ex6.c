
#include <stdio.h>
#include <string.h>
int main(){
	char s[20];
	char inverter[20];
	int x;
	int i;
	printf("digite uma string: ");
	gets(s);
	i = 0;
	for(x = strlen(s)-1; x>= 0;x--){
		inverter[x] = s[i];
		i++;
	}
	printf(" %s = %s",s,inverter);
	return 0;
}
