
#include <stdio.h>
#include <string.h>

char str[50];

void tirarEspaco(char* a){
	int x=0;
	int i=0;
	
	while (a[x] != '\0'){
		if(a[x] != ' ' && a[x] != '\0'){
			str[i] = a[x];
			i++;
		}
		
		x++;
	}
	
	str[i] = '\0';
}


int main(){
	char string[50];
	printf("Por favor, digite uma frase/strings qualquer: ");
	gets(string);
	tirarEspaco(string);
	printf("%s (frase escolhida, sem espaco)", str);
	
	return 0;
}
