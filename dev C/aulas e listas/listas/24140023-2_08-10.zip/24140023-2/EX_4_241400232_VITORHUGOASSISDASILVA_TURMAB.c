#include <stdio.h>

int main () {
	int sete;
	
	sete = 7;	
	
	for (int i = 1; i<10; i++) {
		printf("%d X %d = %d\n",sete,i,sete*i); //sabemos que a logica aritmetica de multiplica��o n�o � o X, mas sim o *
	}	
	
	
	
	
	
	return 0;
}
