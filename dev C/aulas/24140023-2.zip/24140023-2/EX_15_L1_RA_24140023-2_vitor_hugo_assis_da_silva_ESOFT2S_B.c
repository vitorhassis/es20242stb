#include <stdio.h>

//como nao sabemos ainda calcular o tamanho da string, o prof falou pra deixar assim mesmo

int main () {
int senha;	

printf("digite um valor para a senha: ");
scanf("%d",&senha);

	printf("senha validada");
	
		
	return 0;
}
